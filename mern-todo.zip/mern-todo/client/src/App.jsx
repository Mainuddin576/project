import { useEffect, useState } from "react";

export default function App() {
  const [todos, setTodos] = useState([]);
  const [text, setText] = useState("");

  useEffect(() => {
    fetch("/api/todos")
      .then((r) => r.json())
      .then(setTodos);
  }, []);

  const addTodo = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    const res = await fetch("/api/todos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    const todo = await res.json();
    setTodos([todo, ...todos]);
    setText("");
  };

  const toggle = async (todo) => {
    const res = await fetch(`/api/todos/${todo._id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ done: !todo.done }),
    });
    const updated = await res.json();
    setTodos(todos.map((t) => (t._id === updated._id ? updated : t)));
  };

  const remove = async (id) => {
    await fetch(`/api/todos/${id}`, { method: "DELETE" });
    setTodos(todos.filter((t) => t._id !== id));
  };

  return (
    <div className="app">
      <h1>My Todos</h1>

      <form onSubmit={addTodo} className="add">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Kya karna hai?"
        />
        <button>Add</button>
      </form>

      <ul>
        {todos.map((t) => (
          <li key={t._id} className={t.done ? "done" : ""}>
            <input type="checkbox" checked={t.done} onChange={() => toggle(t)} />
            <span>{t.text}</span>
            <button className="del" onClick={() => remove(t._id)}>✕</button>
          </li>
        ))}
      </ul>

      {todos.length === 0 && <p className="empty">Abhi koi todo nahi hai.</p>}
    </div>
  );
}
