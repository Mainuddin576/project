# MERN Todo (simple)

MongoDB + Express + React + Node. Add, complete and delete todos.

## Chalane ka tarika

MongoDB local chalna chahiye (ya Atlas ka URI `.env` me daalo).

**Terminal 1: backend**
```
cd server
cp .env.example .env
npm install
npm run dev
```

**Terminal 2: frontend**
```
cd client
npm install
npm run dev
```

Browser me kholo: http://localhost:5173

## Structure
```
server/server.js     -> model + API routes (ek hi file)
client/src/App.jsx   -> poora UI (ek hi file)
```

## API
| Method | URL              | Kaam            |
|--------|------------------|-----------------|
| GET    | /api/todos       | saare todos     |
| POST   | /api/todos       | naya todo       |
| PUT    | /api/todos/:id   | done toggle     |
| DELETE | /api/todos/:id   | todo delete     |
