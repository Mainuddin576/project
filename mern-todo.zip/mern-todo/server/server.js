require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");

const app = express();
app.use(cors());
app.use(express.json());

// Model
const Todo = mongoose.model(
  "Todo",
  new mongoose.Schema(
    {
      text: { type: String, required: true, trim: true },
      done: { type: Boolean, default: false },
    },
    { timestamps: true }
  )
);

// Routes
app.get("/api/todos", async (req, res) => {
  res.json(await Todo.find().sort({ createdAt: -1 }));
});

app.post("/api/todos", async (req, res) => {
  const text = (req.body.text || "").trim();
  if (!text) return res.status(400).json({ message: "Text is required" });
  res.status(201).json(await Todo.create({ text }));
});

app.put("/api/todos/:id", async (req, res) => {
  const todo = await Todo.findByIdAndUpdate(
    req.params.id,
    { done: req.body.done },
    { new: true }
  );
  if (!todo) return res.status(404).json({ message: "Not found" });
  res.json(todo);
});

app.delete("/api/todos/:id", async (req, res) => {
  await Todo.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted" });
});

// Start
const PORT = process.env.PORT || 5000;
mongoose
  .connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/todo")
  .then(() => {
    console.log("MongoDB connected");
    app.listen(PORT, () => console.log(`Server on http://localhost:${PORT}`));
  })
  .catch((err) => console.error("MongoDB error:", err.message));
